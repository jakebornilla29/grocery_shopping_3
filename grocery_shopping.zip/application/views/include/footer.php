<div class="footer-top-area">
    <div class="zigzag-bottom"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <div class="footer-about-us">
                    <h2>Grocery<span> Shopping</span></h2>
                    <p>Grocery Shopping is about shopping foods or cooking equipments through online.</p>
                    <div class="footer-social">
                        <strong>Our Social Media Networks</strong>
                        <a href="http://facebook.com/Percabeth143" target="_blank"><i class="fa fa-facebook"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="footer-bottom-area">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="copyright">
                    <p>&copy;  2018 GroceryShopping. All Rights Reserved. Coded with <i class="fa fa-smile"></i> by <a href="http://facebook.com/Percabeth143" target="_blank">Jake Bornilla</a></p>
                </div>
            </div>

        </div>
    </div>
</div>
